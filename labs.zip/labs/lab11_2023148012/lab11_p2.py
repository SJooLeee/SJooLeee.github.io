def copyFiles(f1, f2, f3):
    """
    function to copy f1 and f2, and write them to f3
    :param f1: first file to copy
    :param f2: second file to copy
    :param f3: third file to write
    :return: 0
    """
    #open f1,f2 to copy
    try:  # open f1, f2, f3
        f1 = open(f1, 'r')
        f2 = open(f2, 'r')
        # open f3 to write
        f3 = open(f3, 'w')
    except OSError:  # if any one of the files cannot be opened
        return -1  # return -1

    #read line in first file and write lines to third file:
    for line in f1:
        f3.write(line)
    # read line in second file and write lines to third file:
    for line in f2:
        f3.write(line)
    #close file:
    f1.close()
    f2.close()
    #close file:
    f3.close()
    #return 0:
    return 0