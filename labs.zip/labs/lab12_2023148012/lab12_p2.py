def moderateDays(mydict):
    """
    :param mydict: dictionary type
    :return: Returns a list L of the days for which the average
    temperature was between 70 and 79 degrees.
    """
    #make empty list L:
    L=[]
    #check if mydict's key is between 70 and 79:
    for i in mydict.keys():
        if 79>=mydict[i]>=70:
    #if mydict's key satisfy the requirement, append to list L and return L:
            L.append(i)
    return(L)