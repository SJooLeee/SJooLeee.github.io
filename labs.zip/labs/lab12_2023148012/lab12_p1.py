def addDailyTemp(mydict, day, temperature):
    """
    :param mydict: dictionary type
    :param day: key
    :param temperature: value of key
    :return: dictionary mydict
    Add key 'day' and value 'temperature' to the dictionary 'mydict',
    only if key 'day' does not already exist in the dictionary.
    The resulting dictionary is returned.
    """
    #check if day already exist in mydict
    if day not in mydict:
        mydict[day]=temperature
    #return mydict
    return(mydict)

