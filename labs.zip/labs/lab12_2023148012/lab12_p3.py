#import random module
import random
#make encrypting characters lists:
P = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w'
    , 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T'
    , 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ' ', '\n']
R = []
#set encrypting function:
def encrypting(x):
    """
    function to encrypt input x:
    :param x: input
    :return: encrypted characters
    """
    y=''
    #find each characters of x in list P:
    for i in range(len(x)):
        m=P.index(x[i])
    #keep adding characters which correspond to the sequence of list R:
        y += R[m]
    return y
#set decrypting function:
def decrypting(x):
    """
    function to decrypt input x:
    :param x: input
    :return: decrypted characters
    """
    y=''
    #find each characters of x in list R:
    for i in range(len(x)):
        m=R.index(x[i])
    #keep adding characters which correspond to the sequence of list P:
        y+=P[m]
    return y

#set empty string and empty list:
s=''
Q=[]
#get filename:
filename=input('Enter a filename: ')
#split filename by '.':
L=filename.split('.')
#if the file ends with txt, make new encrypting key:
if L[1]=='txt':
    flag = False
    #keep making random sequence of characters before '\n'
    for i in range(len(P) - 1):
        while flag == False:
    # use while statement until x satisfy following requirement:
            x = random.randint(0, 62)
            if i != x and P[x] not in R:
    #add R to P[x] if x satisfied the requirements:
                R.append(P[x])
                flag = True
    #initialize flag to False:
        flag = False
    R.append('\n')
    #open f1 to read
    f1=open(filename, 'r')
    for line in f1:
    #get characters in f1 with encrypting and add to list Q:
        a=encrypting(line)
        Q.append(a)
    #get f2 to write key that shows characters and the encrypted characters:
    f2=open(L[0]+'.key', 'w')
    for i in range(64):
    #get s which is encrypted one:
        s += str(P[i])+','+str(R[i])+'\n'
    #write to f2:
    f2.write(s)
    #get file to write encrypted data:
    f3=open(L[0]+'.enc', 'w')
    for i in range(len(Q)):
    #continue to write each elements of list Q:
        f3.write(str(Q[i]))
#if the file ends with 'enc', decrypt letters in input file:
if L[1] == 'enc':
    f2=open(L[0]+'.key', 'r')
    #open key to decrypt to initial characters:
    for line in f2:
    #prevent if it is '\n':
        if len(line) == 4:
            R.append(line[2])
    #consider '\n' and append to R:
    R.append('\n')
    #open enc file to read:
    f3 = open(filename, 'r')
    for line in f3:
    #get characters in f3 with decrypting and add to list Q:
        a = decrypting(line)
        Q.append(a)
    #open txt file:
    f1=open(L[0]+'.txt', 'w')
    #write f1 to decrypted characters:
    for i in range(len(Q)):
        f1.write(str(Q[i]))
