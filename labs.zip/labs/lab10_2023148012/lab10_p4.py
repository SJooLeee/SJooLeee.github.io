#make empty list:
M=[]
#open file to read:
x=open('data.txt', 'r')
#append each elements of file to list M:
for num in x:
    M.append(int(num))
#insert first element of list M to first place:
M.insert(0, M[0])
#append last element of list M:
M.append(M[-1])
#make empty list:
N=[]
#add average value of three consecutive values:
for i in range(len(M)-2):
    N.append((M[i]+M[i+1]+M[i+2])/3)
#print required list:
print(N)
#close
x.close()