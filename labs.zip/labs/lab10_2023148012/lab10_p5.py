# Sparse Text Program

def createModifiedFile(input_file, output_file):
    '''
        For text file input_file, creates a new version in file output_file
        in which all instances of the vowels are removed.
    '''
    #make variables:
    empty_str = ''
    num_total_chars = 0
    # make variables:
    num_removals = 0

    for line in input_file:
        # save original line length in case of line has '\n'
        if '\n' in line:
            orig_line_length = len(line) - 1
        # save original line length in case of line does not have '\n'
        else:
            orig_line_length = len(line)
        #count total characters of input_file:
        num_total_chars = num_total_chars + orig_line_length
        for x in line:
        #if character of line is in vowel, remove all x:
            if x in 'aeiouAEIOU':
                modified_line = line.replace(x, empty_str)
        #change line to modified line:
                line = modified_line
        #count number of removed vowels in case of '\n' is in line:
        if '\n' in line:
            num_removals += orig_line_length-len(modified_line)+1
        # count number of removed vowels in case of '\n' is not in line:
        else:
            num_removals += orig_line_length-len(modified_line)

        # simulataneouly output line to screen and output file
        print(modified_line.strip('\n'))
        output_file.write(modified_line)
    #return number of total characters of input file, number of characters removed:
    return (num_total_chars, num_removals)


# --- main

# open files for reading
file_name = input('Enter file name (including file extension): ')
input_file = open(file_name, 'r')
# open files for writing
new_file_name = 'new_' + file_name
output_file = open(new_file_name, 'w')

# create file with all vowels removed
print()
num_total_chars, num_removals = createModifiedFile(input_file, output_file)

# close current input and output files
input_file.close()
output_file.close()


print()
#print how many vowels are removed:
print(num_removals, 'vowels removed')
print(num_removals, "out of", num_total_chars, "characters removed")
# display percentage of characters removed
print('Percentage of data lost:',
      int((num_removals / num_total_chars) * 100), '%')
print('Modified text in file', new_file_name)