def countLetters(line):
    """
    function to count the number of alphabet characters
    :param line: string
    """
    L='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVXWYZ'
    #set variable:
    n=0
    #check if characters are alphabet:
    for i in range(len(line)):
        if line[i] in L:
    #count the number of alphabet characters:
            n+=1
    #open answer.txt and write the number:
    myfile = open('answer.txt', 'a')
    myfile.write(str(n) + '\n')
    #close:
    myfile.close()
