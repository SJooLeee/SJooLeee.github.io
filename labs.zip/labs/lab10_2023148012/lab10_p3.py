def countAllLetters(line):
    """
    function to count the number of times that alphabet characters appeared:
    :param line: string
    :return: list that shows the number of times that alphabet character appeared and sort them as alphabetically:
    """
    #make list that will count the number of times that each alphabet characters appear:
    L = [0] * 26
    #change line to string:
    x=str(line)
    for i in range(len(line)):
    #whenever x[i] is small alphabet, add 1 to corresponding list:
        if x[i] in 'abcdefghijklmnopqrstuvwxyz':
            L[ord(x[i])-97] += 1
    # whenever x[i] is large alphabet, add 1 to corresponding list:
        if x[i] in 'ABCDEFGHIJKLMNOPQRSTUVXWYZ':
            L[ord(x[i])-65] += 1
    #make empty list:
    M = []
    for i in range(len(L)):
    #whenever L[i] is not 0, make required element to add to M:
        if L[i] != 0:
            x = (chr(i + 97), L[i])
    #append required elements to M
            M.append(x)
    #return list M
    return(M)