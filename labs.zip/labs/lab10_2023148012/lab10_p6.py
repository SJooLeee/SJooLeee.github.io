# Sparse Text Program

def createModifiedFile(input_file, output_file):
    '''
        For text file input_file, creates a new version in file output_file
        in which all instances of the letter 'e' are removed.
    '''

    empty_str = ''
    #set variables:
    num_total_chars = 0
    num_removals = 0
    #set modified_line as empty:
    modified_line=''

    for line in input_file:
        #set modified_line as empty if line is '\n':
        if line == '\n':
            modified_line = ''
        #check if line is not '\n'
        else:
            # save original line length
            orig_line_length = len(line) - 1
            # if line[0] is empty set variable m as 1:
            if line[0] == ' ':
                m = 1
            # if line[0] is not empty set variable m as 0:
            else:
                m = 0
            #split line and make list l:
            l=line.split()
            #count number of all characters in list l:
            for i in l:
                m += len(i)
            #count modified_line number by adding number of white spaces to m:
            num_modified_line = m + len(l) - 1
            #count total characters number by continually adding number of original line length:
            num_total_chars += orig_line_length
            #count number of removed number:
            num_removals += orig_line_length - num_modified_line
            #if line[0] is white space, do the following:
            if line[0] == ' ':
                for i in range(len(l)):
                    #at first add white space:
                    if i == 0:
                        modified_line=' '+modified_line+l[i]+' '
                    #else if i is not 0: do the following
                    else:
                    #keep adding elements of list l to modified line with white spaces:
                        if i<len(l)-1:
                            modified_line=modified_line+l[i]+' '
                    #lastly add elements of list l to modified line:
                        else:
                            modified_line=modified_line+l[i]
            #if line[0] is not white space, do the following:
            else:
                for i in range(len(l)):
                # keep adding elements of list l to modified line with white spaces:
                    if i<len(l)-1:
                        modified_line=modified_line+l[i]+' '
                # lastly add elements of list l to modified line:
                    else:
                        modified_line=modified_line+l[i]
        #print modified line:
        print(modified_line)
        #initialize modified_line:
        modified_line = ''

        # simulataneouly output line to screen and output file
        output_file.write(modified_line)

    return (num_total_chars, num_removals)


# --- main

# open files for reading
file_name = input('Enter file name (including file extension): ')
input_file = open(file_name, 'r')
# open files for writing
new_file_name = 'r_' + file_name
output_file = open(new_file_name, 'w')

# create file with all letter e removed
print()
num_total_chars, num_removals = createModifiedFile(input_file, output_file)

# close current input and output files
input_file.close()
output_file.close()

# display percentage of characters removed
print()
#print required statements which shows how many whitespace characters are removed:
print(num_removals, "whitespace characters removed")
print(num_removals, "out of", num_total_chars, "characters removed")
#print percentage of data lost:
print('Percentage of data lost:',
      int((num_removals / num_total_chars) * 100), '%')
print('Modified text in file', new_file_name)