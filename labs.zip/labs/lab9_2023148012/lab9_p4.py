def drawFlower(myturtle, r):
    """
    Draws a flower composed of 24 circles
    on the screen: 12 red circles and 12
    blue circles. The radius of the red
    circles is ``r‘’. The radius of the
    blue circles is half of ‘’r’’.
    The turtle ``myturtle'' is already
    positioned in the center of the flower
    :param myturtle: tool to draw circles:
    :param r: radius of red circles:
    """
#hide turtle:
    myturtle.hideturtle()
#to draw 12 circles, devide 360 by 30:
    for x in range(0, 360, 30):
#change pencolor to red to draw red circles:
        myturtle.pencolor('red')
#draw circles according to the given condition with radius of r:
        myturtle.setheading(x)
        myturtle.circle(r)
#change pencolor to red to draw red circles:
        myturtle.pencolor('blue')
#draw circles according to the given condition with radius of r/2:
        myturtle.circle(r/2)
