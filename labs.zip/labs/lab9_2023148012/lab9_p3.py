#import module:
import stack
#print required statements:
print('This program can determine if a given string is a palindrome\n')
print('(Enter return to exit)')
#get list and name c:
c=stack.getStack()
#get input:
s=input('Enter string to check: ')
f=0
#append all characters of input to list c:
for i in range(len(s)):
    stack.push(c, s[i])
#process the program until input is '':
while s != '':
#distinguish when the input is one letter, and print required statement:
    if len(c) == 1:
        print('A one letter word is by definition a palindrome\n')
#process the following if the input is not one letter:
    else:
#process the following if number of characters entered is even
        if len(c) // 2 == 0:
            for i in range(int(len(c) / 2)):
#check if the input is palindrome, change f to 1 if it is not:
                if c[i] != c[-1 - i]:
                    f=1
#print required statment if f equals 0:
            if f == 0:
                print(s, 'is a palindrome\n')
# print required statement if f is not 0:
            else:
                print(s, 'is NOT a palindrome\n')
#process the following if number of characters entered is odd:
        else:
            for i in range(int((len(c) - 1) / 2)):
# check if the input is palindrome, change f to 1 if it is not:
                if c[i] != c[-1 - i]:
                    f=1
#print required statement if f equals 0:
            if f == 0:
                print(s, 'is a palindrome\n')
# print required statement if f is not 0:
            else:
                print(s, 'is NOT a palindrome\n')
#change the conditions to initial state to execute while statement:
    f=0
    s=input('Enter string to check: ')
#same as the above
    c=[]
    for i in range(len(s)):
# same as the above
        stack.push(c, s[i])