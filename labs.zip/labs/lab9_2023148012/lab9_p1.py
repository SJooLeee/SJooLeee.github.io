#import module
import stack
#get list s
s=stack.getStack()
f=()
#get input parentheses and/or braces:
p=input('Enter parentheses and/or braces: ')
#process the following when first character of input is ( or {:
if p[0] == '(' or p[0] == '{':
#for all characters of input, process the following:
    for i in range(len(p)):
#stack p[i] to s if the character is ( or {:
        if p[i] == '(' or p[i] == '{':
            stack.push(s, p[i])
#compare p[i] with the last stacked element of [s] and pop latter one if they match together when p[i] is ) or }:
        else:
            if ord(p[i])-1 == ord(s[-1]) or ord(p[i])-2 == ord(s[-1]):
                stack.pop(s)
#list s remains nothing if all elements of s get matched:
    if len(s) == 0:
        f = 0
#it is not nested properly if p[0] is not ( or {:
else:
    f=1
#print 'Not properly nested.' if is is not nested properly:
if f != 0:
    print('Not properly nested.')
#print 'Nested properly.' if it is nested properly
if f == 0:
    print('Nested properly.')