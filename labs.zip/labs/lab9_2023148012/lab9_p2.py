#import module
import stack
#get list s1:
s1=stack.getStack()
#get input:
p=input('Enter an RPN expression: ')
#split p and change to list that contains character of original p:
p=p.split()
#define f and f2 to process the program:
f=()
f2=()
#process program until F!= True or f==False:
F=True
while F==True and f != False:
#check about all characters in input using for statements:
    for i in range(len(p)):
        for j in range(len(p[i])):
#change f2 to False if any characters of input is not operand or operator:
            if p[i][j] not in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '/', '+', '-', '=']:
                f2 = False
#change F to False if f2 becomes false at least once:
    if f2 == False:
        F = False
#process the following if all characters of input are operand or operator:
    if F == True:
#perform the desired operation for all characters in p:
        for i in range(len(p)):
#check if the last element of p is '='
            if p[-1] == '=':
#if p[i] is operand append p[i] to list s1:
                if p[i] not in ['*', '/', '+', '-', '=']:
                    stack.push(s1, p[i])
#do the following if p[i] is operator:
                else:
                    if p[i] == '*':
#check if it is appropriate evaluation:
                        if len(s1) >= 2:
#pop last two elements of list s1:
                            a = float(s1.pop())
                            b = float(s1.pop())
#calculate required calculation and append result to list s1:
                            s = a * b
                            stack.push(s1, s)
#change f to False if number of remained elements of list is less than 2 so that it is Evaluation error
                        else:
                            f = False
# do the following if p[i] is operator:
                    if p[i] == '/':
# check if it is appropriate evaluation:
                        if len(s1) >= 2:
# pop last two elements of list s1:
                            a = float(s1.pop())
                            b = float(s1.pop())
# check if the denominator is not 0, so it is appropriate evaluation:
                            if a != 0:
# calculate required calculation and append result to list s1:
                                s = b / a
                                stack.push(s1, s)
# change f to False if number of remained elements of list is less than 2 so that it is Evaluation error
                        else:
                            f = False
# do the following if p[i] is operator:
                    if p[i] == '+':
# check if it is appropriate evaluation:
                        if len(s1) >= 2:
# pop last two elements of list s1:
                            a = float(s1.pop())
                            b = float(s1.pop())
#calculate required calculation and append result to list s1:
                            s = a + b
                            stack.push(s1, s)
#change f to False if number of remained elements of list is less than 2 so that it is Evaluation error
                        else:
                            f = False
# do the following if p[i] is operator:
                    if p[i] == '-':
# check if it is appropriate evaluation:
                        if len(s1) >= 2:
# pop last two elements of list s1:
                            a = float(s1.pop())
                            b = float(s1.pop())
#calculate required calculation and append result to list s1:
                            s = b - a
                            stack.push(s1, s)
# change f to False if number of remained elements of list is less than 2 so that it is Evaluation error
                        else:
                            f = False
#proceed with the following after the previous process is performed properly
                    if f != False:
# do the following if p[i] is equality sign:
                        if p[i] == '=':
# change f to the result value if there remains only one element in the list s:
                            if len(s1) == 1:
                                f = s1[0]
# change f to False to show input is inappropriate expression if number of elements in list is not 1:
                            else:
                                f = False
#change f to False to show input is inappropriate expression if the last element of list is not '=':
            else:
                f = False
#do the following if all characters of input are operand or operator:
    if F == True:
#print value of expression if input is appropriate expression:
        if f != False:
#print result as integer if the value of calculation is the same as integer:
            if float.is_integer(f):
                print('Value of expression:', int(f))
#print result up to the second decimalt place if the result is not integer:
            else:
                print('Value of expression:', format(f, '.2f'))
#print Evaluation Error if the expression is inappropriate:
        else:
            print('Evaluation Error')
#terminate program:
            break
#terminate program if any characters in input is not operand or operator:
    else:
        break
#change the conditions to initial state to execute while statement:
    s1 = stack.getStack()
    p = input('Enter an RPN expression: ')
#same as the above
    p = p.split()
    F = True
#same as the above
    f = ()
    f2 = ()